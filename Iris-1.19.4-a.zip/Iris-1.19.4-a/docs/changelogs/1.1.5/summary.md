This is a small bug fix release to support Sodium 0.3.4 on 1.17 and Sodium 0.4.0 alpha 6 on 1.18, while we work on the 1.2.0 update to add shader settings, currently in public beta on our Discord!

⬇️ Download the release here: https://irisshaders.net/download.html
