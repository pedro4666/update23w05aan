Iris 1.2.2 is ready for download, with major performance improvements!

Here's what's changed since 1.2:

⌛ Fixed a regression in 1.2.1 causing low performance around entities
🗣️ Two translations have been updated
🩹 ...as well as some other fixes!

Known potential issues:

❌ SEUS PTGI HRR Test 3 currently has major graphical issues (SEUS PTGI HRR 2.1 is compatible).

⬇️ Download the release here: https://irisshaders.net/download.html

A more detailed changelog is available for those interested: https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.2.2/full.md
