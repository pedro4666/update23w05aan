Iris 1.2.4 has released as a hotfix to fix multiple issues relating to log spam, white dots appearing through walls, and crashes when entering new dimensions, as well as fixing depth of field on 1.17.1+ and fixing an incompatibility with Resolution Control+.

tl;dr: fixed a ton of really bad bugs caused by 1.2.3


⬇️ Download the release here: https://irisshaders.net/download.html
