# Iris 1.2.7 Changelog (trimmed)

Iris 1.2.7 is now available for download for 1.16.5, 1.17.1, 1.18.2, and 1.19.2, improving performance and fixing minor bugs.

**This will be the last release for 1.17.1.**

This release was developed by coderbot and IMS.

**⬇ Download the release here: https://irisshaders.net/download.html**

A more detailed changelog is available for those interested: <https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.2.7/full.md>

