# Iris 1.3.0 Changelog (trimmed)

`<insert PBR picture here>`

Iris 1.3 is now available for download for 1.16.5, 1.18.2, and 1.19.2, finally adding the long-awaited PBR support.

This release also fixes old hand lighting on SEUS Renewed and similar packs.

This release was developed by Pepper and IMS.

**⬇ Download the release here: https://irisshaders.net/download.html**

A more detailed changelog is available for those interested: <https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.3.0/full.md>

