# Iris 1.4 Changelog (trimmed)

Iris 1.4 is now available for download for 1.16.5, 1.18.2, and 1.19.2, adding many OptiFine parity features as well as new features for shader developers.
This release also includes a few bug fixes and DSA support for performance improvements.

**⬇ Download the release here: https://irisshaders.net/download.html**

A more detailed changelog is available for those interested: <https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.4.0/full.md>

