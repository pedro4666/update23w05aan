# Iris 1.4.3 Changelog (trimmed)

Iris 1.4.3 is now available for download for 1.16.5, 1.18.2, 1.19.2, and very soon 1.19.3, fixing multiple issues and improving stability.
This release also adds some debug features.

**This will be the last 1.16.5 release.**

**⬇ Download the release here: https://irisshaders.net/download.html**

A more detailed changelog is available for those interested: <https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.4.3/full.md>

