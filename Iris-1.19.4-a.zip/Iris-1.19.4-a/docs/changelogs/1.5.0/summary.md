# Iris 1.5 Changelog (trimmed)

It's finally ready!

Iris 1.5 has released for 1.18.2, 1.19.2, and 1.19.3, with **full support** for the majority of Optifine shaders.

This includes, but is not limited to:

All versions of Kappa, Nostalgia, and Chocapic,
as well as Simpliccimus, Vanilla+, SEUS PTGI GFME, and Photon!

**⬇ Download the release here: https://irisshaders.net/download.html**

A more detailed changelog is available for those interested: <https://github.com/IrisShaders/Iris/blob/trunk/docs/changelogs/1.5.0/full.md>

