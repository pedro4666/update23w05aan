# Misc development resources

Some useful links for developing Iris:

- OptiFine documentation: https://github.com/sp614x/optifine
- shaderLABS wiki: https://wiki.shaderlabs.org/wiki/Main_Page
