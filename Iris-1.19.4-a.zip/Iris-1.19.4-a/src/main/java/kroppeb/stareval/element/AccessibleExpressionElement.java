package kroppeb.stareval.element;

public interface AccessibleExpressionElement extends ExpressionElement {
}
