package kroppeb.stareval.element;

public interface Element {
}
