package kroppeb.stareval.element.token;

import kroppeb.stareval.element.Element;

public abstract class Token implements Element {
	@Override
	public abstract String toString();
}
