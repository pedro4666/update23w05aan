package kroppeb.stareval.element.tree.partial;

import kroppeb.stareval.element.Element;

public abstract class PartialExpression implements Element {
	@Override
	public abstract String toString();
}
