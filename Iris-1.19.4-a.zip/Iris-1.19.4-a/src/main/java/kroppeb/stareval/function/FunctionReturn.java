package kroppeb.stareval.function;

public class FunctionReturn {
	public boolean booleanReturn;
	public byte byteReturn;
	public short shortReturn;
	public int intReturn;
	public long longReturn;
	public float floatReturn;
	public double doubleReturn;
	public Object objectReturn;
}
