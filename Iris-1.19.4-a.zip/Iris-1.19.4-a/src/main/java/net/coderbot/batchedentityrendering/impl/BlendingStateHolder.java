package net.coderbot.batchedentityrendering.impl;

public interface BlendingStateHolder {
	TransparencyType getTransparencyType();

    void setTransparencyType(TransparencyType transparencyType);
}
