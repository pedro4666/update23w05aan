package net.coderbot.batchedentityrendering.impl;

public interface RenderBuffersExt {
	void beginLevelRendering();
	void endLevelRendering();
}
