package net.coderbot.iris.fantastic;

public enum ParticleRenderingPhase {
	EVERYTHING,
	OPAQUE,
	TRANSLUCENT
}
