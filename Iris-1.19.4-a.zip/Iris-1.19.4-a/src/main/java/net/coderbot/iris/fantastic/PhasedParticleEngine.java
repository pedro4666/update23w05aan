package net.coderbot.iris.fantastic;

public interface PhasedParticleEngine {
	void setParticleRenderingPhase(ParticleRenderingPhase phase);
}
