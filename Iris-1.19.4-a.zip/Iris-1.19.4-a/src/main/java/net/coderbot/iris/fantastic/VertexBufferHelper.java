package net.coderbot.iris.fantastic;

public interface VertexBufferHelper {
	void saveBinding();
	void restoreBinding();
}
