package net.coderbot.iris.gbuffer_overrides.matching;

public enum SpecialCondition {
	ENTITY_EYES,
	BEACON_BEAM,
	GLINT
}
