package net.coderbot.iris.gl;

public enum GlVersion {
	GL_11,
	GL_12,
	GL_30,
	GL_31
}
