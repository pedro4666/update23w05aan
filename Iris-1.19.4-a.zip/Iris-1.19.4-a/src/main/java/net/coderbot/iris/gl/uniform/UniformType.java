package net.coderbot.iris.gl.uniform;

public enum UniformType {
	INT,
	FLOAT,
	MAT3,
	MAT4,
	VEC2,
	VEC2I,
	VEC3,
	VEC4,
	VEC4I
}
