package net.coderbot.iris.gui.screen;

/**
 * Screens implementing this will hide the player hand and HUD
 *
 * Only used for instanceof checks
 */
public interface HudHideable {
}
