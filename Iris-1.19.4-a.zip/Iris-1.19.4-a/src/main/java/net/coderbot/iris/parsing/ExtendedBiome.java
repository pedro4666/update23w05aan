package net.coderbot.iris.parsing;

public interface ExtendedBiome {
	void setBiomeCategory(int biomeCategory);

	int getBiomeCategory();

    float getDownfall();
}
