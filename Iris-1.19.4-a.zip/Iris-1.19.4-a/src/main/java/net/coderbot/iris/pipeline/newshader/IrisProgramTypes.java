package net.coderbot.iris.pipeline.newshader;

import com.mojang.blaze3d.shaders.Program;

public class IrisProgramTypes {
	public static Program.Type GEOMETRY;
}
