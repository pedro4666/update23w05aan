package net.coderbot.iris.pipeline.transform;

public enum Patch {
	ATTRIBUTES,
	VANILLA,
	SODIUM,
	COMPOSITE,
	COMPUTE
}
