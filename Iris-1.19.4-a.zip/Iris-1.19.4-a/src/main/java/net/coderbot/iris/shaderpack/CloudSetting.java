package net.coderbot.iris.shaderpack;

public enum CloudSetting {
	DEFAULT,
	FAST,
	FANCY,
	OFF
}
