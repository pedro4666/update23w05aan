package net.coderbot.iris.shaderpack;

public enum DimensionId {
	OVERWORLD,
	NETHER,
	END
}
